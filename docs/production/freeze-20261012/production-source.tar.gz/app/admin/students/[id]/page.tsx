import { displayLabel } from '@/lib/display'
import StudentJournals from '@/app/admin/learning-journals/StudentJournals'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import ClassEnrollments from './ClassEnrollments'
import AcademicPrograms from './AcademicPrograms'

import {
  updateStudent,
} from '../actions'

import { createClient } from '@/lib/supabase/server'
import { businessDate } from '@/app/admin/_lib/business-date'
import { placementLabel } from '@/app/admin/business/crm/model'

type EditStudentPageProps = {
  params: Promise<{
    id: string
  }>

  searchParams: Promise<{
    error?: string
  }>
}
export default async function EditStudentPage({
  params,
  searchParams,
}: EditStudentPageProps) {
  const { id } = await params
  const { error } = await searchParams

  const supabase = await createClient()

  const { data: student } = await supabase
    .from('students')
    .select(`
      id,
      student_code,
      full_name,
      preferred_name,
      default_branch_id,
      date_of_birth,
      gender,
      phone,
      email,
      address,
      declares_over_18,
      admission_date,
      notes,
      status
    `)
    .eq('id', id)
    .single()

  if (!student) {
    notFound()
  }
  const { data: intake } = await supabase.from('registration_applications').select('application_code, student_over_18, parent_name, parent_phone, zalo_phone, home_address').eq('linked_student_id', student.id).order('completed_at', { ascending: false }).limit(1).maybeSingle()
  const { data: branches } = await supabase.from('branches').select('id, name, status').order('name')
      return (
        <div className="max-w-6xl">
          <Link
            href="/admin/students"
            className="text-sm font-medium text-gray-500 hover:text-gray-900"
          >
            ← Quay lại danh sách học viên
          </Link>

          <div className="mt-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">
                  Hồ sơ học viên
                </p>

                <h1 className="mt-1 text-3xl font-bold text-gray-950">
                  {student.full_name}
                </h1>

                <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-gray-500">
                  <span>{student.student_code}</span>

                  <span>•</span>

                  <span
                    className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
                      student.status === 'ACTIVE'
                        ? 'bg-green-50 text-green-700'
                        : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {displayLabel(student.status)}
                  </span>
                </div>
              </div>
            </div>

            <nav className="mt-6 flex gap-2 overflow-x-auto text-sm" aria-label="Hồ sơ học viên">
              <a className="shrink-0 rounded-full border px-3 py-1" href="#overview">Tổng quan</a>
              <a className="shrink-0 rounded-full border px-3 py-1" href="#learning">Học tập</a>
              <a className="shrink-0 rounded-full border px-3 py-1" href="#shifts">Ca dạy và lịch học</a>
              <a className="shrink-0 rounded-full border px-3 py-1" href={`/admin/students?tab=attendance`}>Điểm danh</a>
              <a className="shrink-0 rounded-full border px-3 py-1" href={`/admin/students?tab=reports&search=${encodeURIComponent(student.student_code)}`}>Báo cáo học tập</a>
              <a className="shrink-0 rounded-full border px-3 py-1" href={`/admin/students?tab=feedback&q=${encodeURIComponent(student.student_code)}`}>Phản hồi</a>
              <a className="shrink-0 rounded-full border px-3 py-1" href="/admin/tuition">Học phí</a>
              <a className="shrink-0 rounded-full border px-3 py-1" href="#history">Lịch sử</a>
            </nav>
            <div id="overview" className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-xl border border-gray-200 bg-white p-4">
  <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
    Ngày đăng ký tại Vibe
  </p>

  <p className="mt-2 font-semibold text-gray-950">
    {student.admission_date ?? '—'}
  </p>

  <p className="mt-1 text-xs text-gray-500">
    Ngày tiếp nhận học sinh, không phải mốc tính học phí.
  </p>
</div>

            </div>
            <div className="mt-4 rounded-xl border border-gray-200 bg-white p-4 text-sm">
              <p className="text-xs font-medium uppercase tracking-wide text-gray-500">Thông tin tiếp nhận{intake?.application_code ? ` ${intake.application_code}` : ''}</p>
              <p className="mt-2">Tuổi: {(student.declares_over_18 ?? intake?.student_over_18) ? 'Trên 18 tuổi' : 'Chưa đánh dấu trên 18 tuổi'}</p>
              <p>Phụ huynh: {intake?.parent_name || 'Không có'}{intake?.parent_phone ? ` · ${intake.parent_phone}` : ''}</p>
              <p>Số Zalo: {student.phone || intake?.zalo_phone || 'Chưa có'}</p>
              <p>Địa chỉ nhà: {student.address || intake?.home_address || 'Chưa có'}</p>
            </div>
            <StudentPlacement studentId={student.id} studentCode={student.student_code} />
            <div id="learning"><AcademicPrograms studentId={student.id} /></div>
            </div>
            <div id="shifts"><ClassEnrollments studentId={student.id} /></div>

            <div id="history"><StudentJournals studentId={student.id} /></div>
            <div className="mt-8">
              <h2 className="text-xl font-semibold text-gray-950">
                Chỉnh sửa hồ sơ
              </h2>

              <p className="mt-1 text-sm text-gray-500">
                Cập nhật thông tin cá nhân và liên hệ.
              </p>
            </div>

      {error && (
        <div className="mt-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {error === 'Academic progress cannot be updated before the scheduled start date'
            ? 'Hành trình đã được ghi nhận. Kết quả học chỉ được cập nhật từ ngày bắt đầu đã chốt.'
            : error}
        </div>
      )}

      <form
        action={updateStudent}
        className="mt-8 space-y-5 rounded-2xl border border-gray-200 bg-white p-6"
      >
        <input type="hidden" name="id" value={student.id} />

        <div className="grid gap-5 md:grid-cols-2">
          <div>
            <label className="mb-2 block text-sm font-medium">
              Mã học viên *
            </label>

            <input
              name="student_code"
              required
              defaultValue={student.student_code}
              className="w-full rounded-lg border border-gray-300 px-3 py-2.5"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium">
              Họ và tên *
            </label>

            <input
              name="full_name"
              required
              defaultValue={student.full_name ?? ''}
              className="w-full rounded-lg border border-gray-300 px-3 py-2.5"
            />
          </div>
        </div>

        <div>
          <label className="mb-2 block text-sm font-medium">
            Tên thường gọi
          </label>

          <input
            name="preferred_name"
            defaultValue={student.preferred_name ?? ''}
            className="w-full rounded-lg border border-gray-300 px-3 py-2.5"
          />
        </div>

        <div>
          <label className="mb-2 block text-sm font-medium">
            Chi nhánh *
          </label>

          <select
            name="default_branch_id"
            required
            defaultValue={student.default_branch_id}
            className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2.5"
          >
            {(branches ?? []).map((branch) => (
              <option key={branch.id} value={branch.id}>
                {branch.name}
                {branch.status !== 'ACTIVE'
                  ? ' (Inactive)'
                  : ''}
              </option>
            ))}
          </select>
        </div>

        <div className="grid gap-5 md:grid-cols-2">
          <div>
            <label className="mb-2 block text-sm font-medium">
              Ngày sinh
            </label>

            <input
              name="date_of_birth"
              type="date"
              defaultValue={student.date_of_birth ?? ''}
              className="w-full rounded-lg border border-gray-300 px-3 py-2.5"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium">
              Giới tính
            </label>

            <select
              name="gender"
              defaultValue={student.gender ?? ''}
              className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2.5"
            >
              <option value="">Chưa cung cấp</option>
              <option value="MALE">Nam</option>
              <option value="FEMALE">Nữ</option>
              <option value="OTHER">Khác</option>
              <option value="UNSPECIFIED">
                Không xác định
              </option>
            </select>
          </div>
        </div>

        <div className="grid gap-5 md:grid-cols-2">
          <div>
            <label className="mb-2 block text-sm font-medium">
              Điện thoại
            </label>

            <input
              name="phone"
              defaultValue={student.phone ?? ''}
              className="w-full rounded-lg border border-gray-300 px-3 py-2.5"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium">
              Email
            </label>

            <input
              name="email"
              type="email"
              defaultValue={student.email ?? ''}
              className="w-full rounded-lg border border-gray-300 px-3 py-2.5"
            />
          </div>
        </div>

        <div>
          <label className="mb-2 block text-sm font-medium">
            Ngày nhập học
          </label>

          <input
            name="admission_date"
            type="date"
            defaultValue={student.admission_date ?? ''}
            className="w-full rounded-lg border border-gray-300 px-3 py-2.5"
          />
        </div>

        <div>
          <label className="mb-2 block text-sm font-medium">
            Địa chỉ
          </label>

          <textarea
            name="address"
            rows={3}
            defaultValue={student.address ?? ''}
            className="w-full resize-none rounded-lg border border-gray-300 px-3 py-2.5"
          />
        </div>

        <div>
          <label className="mb-2 block text-sm font-medium">
            Ghi chú
          </label>

          <textarea
            name="notes"
            rows={4}
            defaultValue={student.notes ?? ''}
            className="w-full resize-none rounded-lg border border-gray-300 px-3 py-2.5"
          />
        </div>

        <div className="rounded-xl bg-gray-50 p-4">
          <p className="text-xs text-gray-500">
            Trạng thái hiện tại
          </p>

          <p className="mt-1 font-semibold text-gray-900">
            {displayLabel(student.status)}
          </p>
        </div>

        <div className="flex gap-3">
          <button
            type="submit"
            className="rounded-lg bg-gray-950 px-5 py-2.5 text-sm font-semibold text-white"
          >
            Lưu thay đổi
          </button>

          <Link
            href="/admin/students"
            className="rounded-lg border border-gray-300 px-5 py-2.5 text-sm font-medium"
          >
            Hủy
          </Link>
        </div>
      </form>
    </div>
  )
}

async function StudentPlacement({ studentId, studentCode }: { studentId: string; studentCode: string }) {
  const db = await createClient()
  const [{ data: applications }, { data: placements }] = await Promise.all([
    db.from('registration_applications').select('id, application_code, status, curriculum_id, level_id, desired_start_date').eq('linked_student_id', studentId).order('completed_at', { ascending: false }).limit(5),
    db.from('student_placement_cases').select('id, status, scheduled_start_date, desired_start_date, assigned_class_id, curriculum_id, level_id').eq('student_id', studentId).order('opened_at', { ascending: false }).limit(5),
  ])
  if (!applications?.length && !placements?.length) return null
  const curriculumIds = [...new Set([...(applications ?? []), ...(placements ?? [])].map(item => item.curriculum_id).filter((id): id is string => Boolean(id)))]
  const levelIds = [...new Set([...(applications ?? []), ...(placements ?? [])].map(item => item.level_id).filter((id): id is string => Boolean(id)))]
  const [{ data: curriculums }, { data: levels }] = await Promise.all([
    curriculumIds.length ? db.from('curriculums').select('id, name').in('id', curriculumIds) : Promise.resolve({ data: [] }),
    levelIds.length ? db.from('curriculum_levels').select('id, name').in('id', levelIds) : Promise.resolve({ data: [] }),
  ])
  const curriculumName = new Map((curriculums ?? []).map(item => [item.id, item.name]))
  const levelName = new Map((levels ?? []).map(item => [item.id, item.name]))
  const today = businessDate()
  const waiting = (placements ?? []).some(placement => placement.status === 'UNASSIGNED' || placement.status === 'MATCHING')
  return (
    <section className="mt-6 rounded-xl border border-gray-200 bg-white p-4 text-sm">
      <h2 className="font-semibold text-gray-950">Hành trình và ca dạy</h2>
      <ul className="mt-3 space-y-2">
        {(placements ?? []).map(placement => <li key={placement.id}>{curriculumName.get(placement.curriculum_id ?? '') || 'Chương trình'} · {levelName.get(placement.level_id ?? '') || 'Trình độ'} · {placementLabel(placement.status, placement.scheduled_start_date, today)}{placement.desired_start_date ? ` · ngày vào ca ${placement.desired_start_date}` : ''}</li>)}
        {(applications ?? []).map(application => <li key={application.id}>Hồ sơ {application.application_code} · {application.status === 'COMPLETED' ? 'đã hoàn tất đăng ký' : application.status}</li>)}
      </ul>
      {waiting && <p className="mt-3"><Link className="inline-flex rounded-lg bg-gray-950 px-3 py-2 text-sm font-semibold text-white" href={`/admin/students?tab=waiting&q=${encodeURIComponent(studentCode)}`}>Sắp vào ca dạy</Link></p>}
    </section>
  )
}
