'use server'

import { refresh, revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

import { createClient } from '@/lib/supabase/server'
import { primaryShiftWouldExceedTwo, type ShiftSlot } from '@/lib/teaching-shifts/overlap'

const UUID_PATTERN =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

async function requireSuperAdmin() {
  const supabase = await createClient()

  const { data: claimsData, error: claimsError } =
    await supabase.auth.getClaims()

  if (claimsError || !claimsData?.claims) {
    redirect('/login')
  }

  const { data: isSuperAdmin, error: roleError } =
    await supabase.rpc('has_role', {
      role_code: 'SUPER_ADMIN',
    })

  if (roleError || !isSuperAdmin) {
    redirect('/login?error=Unauthorized')
  }

  return supabase
}

function timeToMinutes(value: string) {
  const [hours, minutes] = value
    .slice(0, 5)
    .split(':')
    .map(Number)

  return hours * 60 + minutes
}

function parse12HourTime(
  timeValue: FormDataEntryValue | null,
  periodValue: FormDataEntryValue | null
) {
  const match = String(timeValue ?? '')
    .trim()
    .match(/^(\d{1,2})(?::([0-5]\d))?$/)
  const period = String(periodValue ?? '')

  if (
    !match ||
    !['AM', 'PM'].includes(period)
  ) {
    return null
  }

  const hour = Number(match[1])
  const minute = Number(match[2] ?? '0')

  if (
    hour < 1 ||
    hour > 12 ||
    minute < 0 ||
    minute > 59
  ) {
    return null
  }

  const hour24 =
    period === 'AM'
      ? hour % 12
      : (hour % 12) + 12

  return `${String(hour24).padStart(2, '0')}:${String(
    minute
  ).padStart(2, '0')}`
}

function minutesToTime(totalMinutes: number) {
  const hours = Math.floor(totalMinutes / 60)
  const minutes = totalMinutes % 60

  return `${String(hours).padStart(2, '0')}:${String(
    minutes
  ).padStart(2, '0')}`
}

function timeRangesOverlap(
  startA: string,
  endA: string,
  startB: string,
  endB: string
) {
  return (
    timeToMinutes(startA) < timeToMinutes(endB) &&
    timeToMinutes(endA) > timeToMinutes(startB)
  )
}

function dateRangesOverlap(
  startA: string,
  endA: string | null,
  startB: string,
  endB: string | null
) {
  const aEnd = endA ?? '9999-12-31'
  const bEnd = endB ?? '9999-12-31'

  return startA <= bEnd && aEnd >= startB
}

export async function createSchedule(
  formData: FormData
) {
  const supabase = await requireSuperAdmin()

  const classId = String(
    formData.get('class_id') ?? ''
  ).trim()

  const roomId = String(
    formData.get('room_id') ?? ''
  ).trim()

  const daysOfWeek = Array.from(
    new Set(
      formData
        .getAll('day_of_week')
        .map((value) => Number(value))
    )
  ).sort((a, b) => a - b)

  const startTime = parse12HourTime(
    formData.get('start_time'),
    formData.get('start_period')
  )

  const durationMinutes = Number(
    formData.get('duration_minutes')
  )

  const endMinuteValue = startTime
    ? timeToMinutes(startTime) + durationMinutes
    : 0

  const endTime =
    Number.isInteger(durationMinutes) &&
    [45, 60, 90, 120].includes(durationMinutes) &&
    endMinuteValue < 24 * 60
      ? minutesToTime(endMinuteValue)
      : null

  const effectiveFrom = String(
    formData.get('effective_from') ?? ''
  ).trim()

  const effectiveToRaw = String(
    formData.get('effective_to') ?? ''
  ).trim()

  const effectiveTo =
    effectiveToRaw || null

  const notes = String(
    formData.get('notes') ?? ''
  ).trim()

  if (
    !classId ||
    !roomId ||
    daysOfWeek.length === 0 ||
    !startTime ||
    !endTime ||
    !effectiveFrom
  ) {
    redirect(
      '/admin/schedule?error=Please%20complete%20all%20required%20fields'
    )
  }

  if (
    daysOfWeek.some(
      (dayOfWeek) =>
        !Number.isInteger(dayOfWeek) ||
        dayOfWeek < 1 ||
        dayOfWeek > 7
    )
  ) {
    redirect(
      '/admin/schedule?error=Invalid%20day%20of%20week'
    )
  }

  if (
    timeToMinutes(endTime) <=
    timeToMinutes(startTime)
  ) {
    redirect(
      '/admin/schedule?error=End%20time%20must%20be%20after%20start%20time'
    )
  }

  if (
    effectiveTo &&
    effectiveTo < effectiveFrom
  ) {
    redirect(
      '/admin/schedule?error=End%20date%20cannot%20be%20before%20start%20date'
    )
  }

  // --------------------------------------------------
  // CLASS VALIDATION
  // --------------------------------------------------

  const { data: classItem } = await supabase
    .from('classes')
    .select(
      'id, branch_id, code, name, status'
    )
    .eq('id', classId)
    .maybeSingle()

  if (!classItem) {
    redirect(
      '/admin/schedule?error=Class%20not%20found'
    )
  }

  if (
    ['COMPLETED', 'CANCELLED'].includes(
      classItem.status
    )
  ) {
    redirect(
      '/admin/schedule?error=Cannot%20schedule%20a%20completed%20or%20cancelled%20class'
    )
  }

  // --------------------------------------------------
  // ROOM MUST BELONG TO SAME BRANCH
  // --------------------------------------------------

  const { data: room } = await supabase
    .from('rooms')
    .select(
      'id, branch_id, code, name, status'
    )
    .eq('id', roomId)
    .maybeSingle()

  if (!room || room.status !== 'ACTIVE') {
    redirect(
      '/admin/schedule?error=Room%20is%20not%20available'
    )
  }

  if (
    room.branch_id !== classItem.branch_id
  ) {
    redirect(
      '/admin/schedule?error=Room%20must%20belong%20to%20the%20same%20branch%20as%20the%20class'
    )
  }

  // --------------------------------------------------
  // LOAD ACTIVE SCHEDULES ON SAME WEEKDAY
  // --------------------------------------------------

  const { data: existingSchedules } =
    await supabase
      .from('schedules')
      .select(`
        id,
        class_id,
        room_id,
        day_of_week,
        start_time,
        end_time,
        effective_from,
        effective_to,
        status
      `)
      .in('day_of_week', daysOfWeek)
      .eq('status', 'ACTIVE')

  const conflictingSchedules =
    (existingSchedules ?? []).filter(
      (schedule) =>
        timeRangesOverlap(
          startTime,
          endTime,
          schedule.start_time,
          schedule.end_time
        ) &&
        dateRangesOverlap(
          effectiveFrom,
          effectiveTo,
          schedule.effective_from,
          schedule.effective_to
        )
    )

  // --------------------------------------------------
  // CLASS CANNOT BE IN TWO PLACES AT ONCE
  // --------------------------------------------------

  const classConflict =
    conflictingSchedules.find(
      (schedule) =>
        schedule.class_id === classId
    )

  if (classConflict) {
    redirect(
      '/admin/schedule?error=This%20class%20already%20has%20an%20overlapping%20schedule'
    )
  }

  // --------------------------------------------------
  // ROOM CANNOT HOST TWO CLASSES AT ONCE
  // --------------------------------------------------

  const roomConflict =
    conflictingSchedules.find(
      (schedule) =>
        schedule.room_id === roomId
    )

  if (roomConflict) {
    redirect(
      '/admin/schedule?error=This%20room%20is%20already%20occupied%20during%20that%20time'
    )
  }

  // --------------------------------------------------
  // TEACHER CONFLICT CHECK
  // Current architecture assigns teachers at class level.
  // --------------------------------------------------

  const { data: currentTeacherAssignments } =
    await supabase
      .from('class_teachers')
      .select('teacher_id, teacher_role')
      .eq('class_id', classId)
      .eq('is_active', true)

  const assistantIds = (currentTeacherAssignments ?? [])
    .filter(assignment => assignment.teacher_role === 'ASSISTANT')
    .map(assignment => assignment.teacher_id)
  const primaryIds = (currentTeacherAssignments ?? [])
    .filter(assignment => assignment.teacher_role === 'PRIMARY')
    .map(assignment => assignment.teacher_id)
  const teacherIds = [...assistantIds, ...primaryIds]

  if (teacherIds.length > 0) {
    const { data: otherTeacherAssignments } =
      await supabase
        .from('class_teachers')
        .select('class_id, teacher_id, teacher_role')
        .in('teacher_id', teacherIds)
        .eq('is_active', true)

    const otherRows = (otherTeacherAssignments ?? []).filter(row => row.class_id !== classId)
    const assistantClassIds = new Set(otherRows.filter(row => assistantIds.includes(row.teacher_id)).map(row => row.class_id))
    if (conflictingSchedules.some(schedule => assistantClassIds.has(schedule.class_id))) {
      redirect('/admin/schedule?error=' + encodeURIComponent('Giáo viên phụ của ca dạy đã có lịch trùng thời gian.'))
    }

    const primaryClassIds = new Set(
      otherRows.filter(row => row.teacher_role === 'PRIMARY' && primaryIds.includes(row.teacher_id)).map(row => row.class_id)
    )
    for (const dayOfWeek of daysOfWeek) {
      const candidate: ShiftSlot = {
        classId,
        dayOfWeek,
        startTime,
        endTime,
        effectiveFrom,
        effectiveTo,
      }
      const others: ShiftSlot[] = conflictingSchedules
        .filter(schedule => schedule.day_of_week === dayOfWeek && primaryClassIds.has(schedule.class_id))
        .map(schedule => ({
          classId: schedule.class_id,
          dayOfWeek: schedule.day_of_week,
          startTime: String(schedule.start_time),
          endTime: String(schedule.end_time),
          effectiveFrom: schedule.effective_from,
          effectiveTo: schedule.effective_to,
        }))
      if (primaryShiftWouldExceedTwo(candidate, others)) {
        redirect('/admin/schedule?error=' + encodeURIComponent('Giáo viên chính đã có hai ca dạy trùng thời gian. Hãy chọn giáo viên khác hoặc đổi lịch.'))
      }
    }
  }

  // --------------------------------------------------
  // CREATE MASTER SCHEDULE
  // --------------------------------------------------

  const { error } = await supabase
    .from('schedules')
    .insert(
      daysOfWeek.map((dayOfWeek) => ({
        class_id: classId,
        room_id: roomId,
        day_of_week: dayOfWeek,
        start_time: startTime,
        end_time: endTime,
        effective_from: effectiveFrom,
        effective_to: effectiveTo,
        timezone: 'Asia/Ho_Chi_Minh',
        notes: notes || null,
        status: 'ACTIVE',
      }))
    )

  if (error) {
    console.error(
      'Create schedule error:',
      error
    )

    if (error.code === '23505') {
      redirect(
        '/admin/schedule?error=This%20schedule%20already%20exists'
      )
    }

    if (error.message.includes('two overlapping')) {
      redirect('/admin/schedule?error=' + encodeURIComponent('Giáo viên chính đã có hai ca dạy trùng thời gian. Hãy chọn giáo viên khác hoặc đổi lịch.'))
    }

    if (error.message.includes('already teaching')) {
      redirect('/admin/schedule?error=' + encodeURIComponent('Giáo viên của ca dạy đã có lịch trùng thời gian.'))
    }

    redirect(
      '/admin/schedule?error=Could%20not%20create%20schedule'
    )
  }

  revalidatePath('/admin')
  revalidatePath('/admin/schedule')
  revalidatePath(
    `/admin/classes/${classId}`
  )

  redirect(
    `/admin/schedule?success=${encodeURIComponent(
      `${daysOfWeek.length} weekly schedule${
        daysOfWeek.length === 1 ? '' : 's'
      } created successfully`
    )}`
  )
}

export async function setScheduleStatus(
  formData: FormData
) {
  const supabase = await requireSuperAdmin()

  const id = String(
    formData.get('id') ?? ''
  ).trim()

  const status = String(
    formData.get('status') ?? ''
  ).trim()

  if (
    !id ||
    !['ACTIVE', 'INACTIVE'].includes(
      status
    )
  ) {
    redirect(
      '/admin/schedule?error=Invalid%20schedule%20status'
    )
  }

  const { error } = await supabase
    .from('schedules')
    .update({ status })
    .eq('id', id)

  if (error) {
    console.error(
      'Schedule status error:',
      error
    )

    redirect(
      '/admin/schedule?error=Could%20not%20update%20schedule'
    )
  }

  revalidatePath('/admin')
  revalidatePath('/admin/schedule')

  redirect(
    '/admin/schedule?success=Schedule%20status%20updated'
  )
}

export async function deleteSchedule(formData: FormData) {
  const supabase = await requireSuperAdmin()

  const id = String(formData.get('id') ?? '').trim()

  if (!UUID_PATTERN.test(id)) {
    redirect(
      '/admin/schedule?error=Invalid%20schedule'
    )
  }

  const { data: schedule, error: scheduleError } =
    await supabase
      .from('schedules')
      .select('id, class_id')
      .eq('id', id)
      .maybeSingle()

  if (scheduleError || !schedule) {
    redirect(
      '/admin/schedule?error=Schedule%20not%20found'
    )
  }

  const { count, error: occurrenceError } =
    await supabase
      .from('session_occurrences')
      .select('id', { count: 'exact', head: true })
      .eq('schedule_id', id)

  if (occurrenceError) {
    console.error(
      'Check schedule sessions error:',
      occurrenceError
    )

    redirect(
      '/admin/schedule?error=Could%20not%20verify%20schedule%20history'
    )
  }

  if ((count ?? 0) > 0) {
    redirect(
      '/admin/schedule?error=This%20schedule%20already%20has%20sessions.%20Deactivate%20it%20to%20preserve%20attendance%20history'
    )
  }

  const {
    data: deletedSchedule,
    error,
  } = await supabase
    .from('schedules')
    .delete()
    .eq('id', id)
    .select('id')
    .maybeSingle()

  if (error || !deletedSchedule) {
    console.error('Delete schedule error:', error)

    const message =
      error?.code === '23503'
        ? 'This schedule now has related sessions. Deactivate it instead'
        : 'Schedule was not deleted. Please reload and try again'

    redirect(
      `/admin/schedule?error=${encodeURIComponent(message)}`
    )
  }

  revalidatePath('/admin')
  revalidatePath('/admin/schedule')
  revalidatePath(`/admin/classes/${schedule.class_id}`)
  refresh()

  redirect(
    '/admin/schedule?success=Schedule%20deleted'
  )
}
