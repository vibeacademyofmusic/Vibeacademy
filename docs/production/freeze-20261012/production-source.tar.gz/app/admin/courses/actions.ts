'use server'

import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

import { createClient } from '@/lib/supabase/server'

const UUID_PATTERN =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

async function requireSuperAdmin() {
  const supabase = await createClient()

  const { data: claimsData, error: claimsError } =
    await supabase.auth.getClaims()

  if (claimsError || !claimsData?.claims) {
    redirect('/login')
  }

  const { data: isSuperAdmin, error: roleError } =
    await supabase.rpc('has_role', {
      role_code: 'SUPER_ADMIN',
    })

  if (roleError || !isSuperAdmin) {
    redirect('/login?error=Unauthorized')
  }

  return supabase
}

export async function createCourse(_formData: FormData) {
  redirect('/admin/programs?error=' + encodeURIComponent('Không tạo khóa học mới. Lộ trình là Chương trình, Trình độ, Môn học, Bài học. Ca dạy là lớp.'))
}

export async function setCourseStatus(formData: FormData) {
  const supabase = await requireSuperAdmin()

  const id = String(formData.get('id') ?? '').trim()
  const status = String(
    formData.get('status') ?? ''
  ).trim()

  if (
    !id ||
    !['ACTIVE', 'INACTIVE'].includes(status)
  ) {
    redirect(
      '/admin/courses?error=Invalid%20course%20status'
    )
  }

  const { error } = await supabase
    .from('courses')
    .update({
      status,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)

  if (error) {
    redirect(
      '/admin/courses?error=Could%20not%20change%20course%20status'
    )
  }

  revalidatePath('/admin')
  revalidatePath('/admin/courses')

  redirect(
    '/admin/courses?success=Course%20status%20updated'
  )
}

export async function updateCourse(formData: FormData) {
  const supabase = await requireSuperAdmin()

  const id = String(formData.get('id') ?? '').trim()
  const curriculumId = String(
    formData.get('curriculum_id') ?? ''
  ).trim()
  const levelIdValue = String(
    formData.get('level_id') ?? ''
  ).trim()
  const levelId = levelIdValue || null
  const code = String(formData.get('code') ?? '')
    .normalize('NFKC')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .trim()
    .replace(/\s+/g, '_')
    .toUpperCase()
  const name = String(formData.get('name') ?? '').trim()
  const description = String(
    formData.get('description') ?? ''
  ).trim()
  const status = String(
    formData.get('status') ?? ''
  ).trim()

  if (
    !UUID_PATTERN.test(id) ||
    !curriculumId ||
    !code ||
    !name ||
    !['ACTIVE', 'INACTIVE'].includes(status)
  ) {
    redirect(
      `/admin/courses/${id}/edit?error=Please%20complete%20all%20required%20fields`
    )
  }

  if (!/^[A-Z0-9_-]{2,50}$/.test(code)) {
    redirect(
      `/admin/courses/${id}/edit?error=Invalid%20course%20code`
    )
  }

  const { data: curriculum } = await supabase
    .from('operational_curriculums')
    .select('id')
    .eq('id', curriculumId)
    .maybeSingle()

  if (!curriculum) {
    redirect(
      `/admin/courses/${id}/edit?error=Invalid%20or%20inactive%20curriculum`
    )
  }

  if (levelId) {
    const { data: level } = await supabase
      .from('curriculum_levels')
      .select('id')
      .eq('id', levelId)
      .eq('curriculum_id', curriculumId)
      .eq('status', 'ACTIVE')
      .maybeSingle()

    if (!level) {
      redirect(
        `/admin/courses/${id}/edit?error=Selected%20level%20does%20not%20belong%20to%20this%20curriculum`
      )
    }
  }

  const { data: updatedCourse, error } = await supabase
    .from('courses')
    .update({
      curriculum_id: curriculumId,
      level_id: levelId,
      code,
      name,
      description: description || null,
      status,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select('id')
    .maybeSingle()

  if (error || !updatedCourse) {
    const message =
      error?.code === '23505'
        ? 'This course code already exists'
        : 'Could not update course'

    redirect(
      `/admin/courses/${id}/edit?error=${encodeURIComponent(message)}`
    )
  }

  revalidatePath('/admin')
  revalidatePath('/admin/courses')
  revalidatePath('/admin/classes')
  revalidatePath(`/admin/courses/${id}/edit`)

  redirect('/admin/courses?success=Course%20updated')
}

export async function deleteCourse(formData: FormData) {
  const supabase = await requireSuperAdmin()
  const id = String(formData.get('id') ?? '').trim()

  if (!UUID_PATTERN.test(id)) {
    redirect('/admin/courses?error=Invalid%20course')
  }

  const { count, error: classesError } =
    await supabase
      .from('classes')
      .select('id', { count: 'exact', head: true })
      .eq('course_id', id)

  if (classesError) {
    redirect(
      '/admin/courses?error=Could%20not%20verify%20course%20usage'
    )
  }

  if ((count ?? 0) > 0) {
    redirect(
      '/admin/courses?error=This%20course%20is%20used%20by%20one%20or%20more%20classes.%20Delete%20those%20classes%20first'
    )
  }

  const { data: deletedCourse, error } = await supabase
    .from('courses')
    .delete()
    .eq('id', id)
    .select('id')
    .maybeSingle()

  if (error || !deletedCourse) {
    console.error('Delete course error:', error)

    const message =
      error?.code === '23503'
        ? 'This course is now in use and cannot be deleted'
        : 'Course was not deleted. Please reload and try again'

    redirect(
      `/admin/courses?error=${encodeURIComponent(message)}`
    )
  }

  revalidatePath('/admin')
  revalidatePath('/admin/courses')
  revalidatePath('/admin/classes')

  redirect('/admin/courses?success=Course%20deleted')
}
