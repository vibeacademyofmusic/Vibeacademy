import Link from 'next/link'
import { mayViewFinancialReports } from '@/lib/auth/financial-reports'
import { OtherFinanceNavigation } from './SectionNav'
import type { ReactNode } from 'react'

const links = [
  ['', 'Tổng quan'],
  ['/invoices', 'Hóa đơn'],
  ['/payments', 'Thanh toán học phí'],
  ['/receivables', 'Công nợ'],
  ['/operating-expenses', 'Chi phí vận hành'],
  ['/refunds', 'Hoàn tiền'],
  ['/credits', 'Số dư khách hàng'],
]

const related = [
  ['/admin/payroll', 'Kỳ lương'],
  ['/admin/hr/payslips', 'Phiếu lương & chi trả'],
]

export default async function FinanceLayout({ children }: { children: ReactNode }) {
  const reports = await mayViewFinancialReports(null)
  const visible = reports ? links : links.filter(([path]) => path !== '')
  return (
    <div className="min-w-0 space-y-6">
      <OtherFinanceNavigation><nav aria-label="Điều hướng tài chính" className="flex flex-wrap gap-2">
        {visible.map(([path, label]) => (
          <Link key={path} prefetch={false} href={'/admin/finance' + path} className="rounded border border-gray-200 bg-white px-3 py-2 text-sm hover:bg-gray-100">{label}</Link>
        ))}
        {related.map(([href, label]) => (
          <Link key={href} prefetch={false} href={href} className="rounded border border-gray-200 bg-white px-3 py-2 text-sm hover:bg-gray-100">{label}</Link>
        ))}
        <Link prefetch={false} href="/finance" className="rounded border px-3 py-2 text-sm">Yêu cầu phê duyệt</Link>
      </nav></OtherFinanceNavigation>
      {children}
    </div>
  )
}
