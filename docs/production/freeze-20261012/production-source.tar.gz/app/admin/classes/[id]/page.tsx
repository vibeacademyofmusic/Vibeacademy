import Link from 'next/link'
import { notFound } from 'next/navigation'
import StudentEnrollmentSection from './StudentEnrollmentSection'
import { createClient } from '@/lib/supabase/server'
import { setClassLevelScope } from '../actions'

import {
  assignTeacher,
  removeTeacher,
} from './actions'

type ClassDetailPageProps = {
  params: Promise<{
    id: string
  }>

  searchParams: Promise<{
    error?: string
    success?: string
  }>
}

export default async function ClassDetailPage({
  params,
  searchParams,
}: ClassDetailPageProps) {
  const { id } = await params
  const { error, success } = await searchParams

  const supabase = await createClient()

  const { data: classItem } = await supabase
    .from('classes')
    .select(`
      id,
      branch_id,
      course_id,
      curriculum_id,
      code,
      name,
      class_type,
      capacity,
      start_date,
      end_date,
      notes,
      status,
      accepted_from_level_id,
      accepted_to_level_id
    `)
    .eq('id', id)
    .maybeSingle()

  if (!classItem) {
    notFound()
  }

  const { data: branch } = await supabase
    .from('branches')
    .select('id, code, name')
    .eq('id', classItem.branch_id)
    .maybeSingle()

  const { data: course } = classItem.course_id
    ? await supabase
      .from('courses')
      .select('id, code, name, curriculum_id, level_id')
      .eq('id', classItem.course_id)
      .maybeSingle()
    : { data: null }

  const programId = classItem.curriculum_id || course?.curriculum_id || null
  const { data: program } = programId
    ? await supabase.from('curriculums').select('id, code, name').eq('id', programId).maybeSingle()
    : { data: null }

  const { data: levels } = programId
    ? await supabase.from('curriculum_levels').select('id, name, sequence_no').eq('curriculum_id', programId).eq('status', 'ACTIVE').order('sequence_no')
    : { data: [] as { id: string; name: string; sequence_no: number }[] }

  const fromLevel = levels?.find(l => l.id === classItem.accepted_from_level_id)
  const toLevel = levels?.find(l => l.id === classItem.accepted_to_level_id)
  const scopeLabel = fromLevel && toLevel ? `${fromLevel.name} → ${toLevel.name}` : 'Chưa cấu hình phạm vi'
  const { count: enrolledStudents } = await supabase
    .from('enrollments')
    .select('id', {
      count: 'exact',
      head: true,
    })
    .eq('class_id', classItem.id)
    .in('status', ['ACTIVE', 'PAUSED'])

  const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Ho_Chi_Minh' }).format(new Date())
  const { data: upcomingSessions } = await supabase
    .from('session_occurrences')
    .select('id, occurrence_date, starts_at, status, occurrence_type, schedules!inner(class_id)')
    .eq('schedules.class_id', classItem.id)
    .gte('occurrence_date', today)
    .order('starts_at')
    .limit(5)

  const { data: activeTeachers } = await supabase
    .from('teachers')
    .select(`
      id,
      teacher_code,
      full_name,
      preferred_name,
      status
    `)
    .eq('status', 'ACTIVE')
    .order('full_name', { ascending: true })

  const { data: teacherAssignments } = await supabase
    .from('class_teachers')
    .select(`
      id,
      teacher_id,
      teacher_role,
      assigned_at,
      is_active
    `)
    .eq('class_id', classItem.id)
    .eq('is_active', true)
    .order('assigned_at', { ascending: true })

  const teacherMap = new Map(
    (activeTeachers ?? []).map((teacher) => [
      teacher.id,
      teacher,
    ])
  )

  const assignedTeacherIds = new Set(
    (teacherAssignments ?? []).map(
      (assignment) => assignment.teacher_id
    )
  )

  const availableTeachers = (
    activeTeachers ?? []
  ).filter(
    (teacher) =>
      !assignedTeacherIds.has(teacher.id)
  )

  const assignedTeachers =
    teacherAssignments?.length ?? 0

  const primaryTeacher =
    teacherAssignments?.find(
      (assignment) =>
        assignment.teacher_role === 'PRIMARY'
    )

  return (
    <div className="max-w-6xl">
      <Link
        href="/admin/classes?view=classes"
        className="text-sm font-medium text-gray-500 hover:text-gray-900"
      >
        ← Ca dạy
      </Link>

      <div className="mt-6">
        <p className="text-sm font-medium text-gray-500">
          Ca dạy
        </p>

        <div className="mt-1 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-gray-950">
              {classItem.name}
            </h1>

            <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-gray-500">
              <span>{classItem.code}</span>

              <span>•</span>

              <span
                className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
                  classItem.status === 'ACTIVE'
                    ? 'bg-green-50 text-green-700'
                    : classItem.status === 'DRAFT'
                      ? 'bg-amber-50 text-amber-700'
                      : classItem.status ===
                          'COMPLETED'
                        ? 'bg-blue-50 text-blue-700'
                        : 'bg-gray-100 text-gray-600'
                }`}
              >
                {classItem.status}
              </span>
            </div>
          </div>
        </div>

        {error && (
          <div className="mt-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        )}

        {success && (
          <div className="mt-6 rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
            {success}
          </div>
        )}

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-xl border border-gray-200 bg-white p-4">
            <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
              Chương trình
            </p>

            <p className="mt-2 font-semibold text-gray-950">
              {program?.name ?? 'Chưa chọn chương trình'}
            </p>

            <p className="mt-1 text-xs text-gray-400">
              {program?.code ?? '—'}
            </p>
            <p className="mt-2 text-xs text-gray-500">{course ? `Khóa học cũ: ${course.name}` : 'Không cần khóa học cũ. Trình độ hiện tại thuộc từng học viên.'}</p>
          </div>

          <div className="rounded-xl border border-gray-200 bg-white p-4">
            <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
              Phạm vi trình độ
            </p>
            <p className="mt-2 font-semibold text-gray-950">{scopeLabel}</p>
            <p className="mt-1 text-xs text-gray-400">Không gọi đây là “Trình độ lớp”. Trình độ hiện tại thuộc từng học viên.</p>
          </div>

          <div className="rounded-xl border border-gray-200 bg-white p-4">
            <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
              Branch
            </p>

            <p className="mt-2 font-semibold text-gray-950">
              {branch?.name ?? 'Not found'}
            </p>

            <p className="mt-1 text-xs text-gray-400">
              {branch?.code ?? '—'}
            </p>
          </div>

          <div className="rounded-xl border border-gray-200 bg-white p-4">
            <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
              Class Type
            </p>

            <p className="mt-2 font-semibold text-gray-950">
              {classItem.class_type === 'ONE_ON_ONE'
                ? '1-on-1'
                : 'Group'}
            </p>

            <p className="mt-1 text-xs text-gray-400">
              Capacity: {classItem.capacity}
            </p>
          </div>

          <div className="rounded-xl border border-gray-200 bg-white p-4">
            <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
              Enrollment
            </p>

            <p className="mt-2 font-semibold text-gray-950">
              {enrolledStudents ?? 0} /{' '}
              {classItem.capacity}
            </p>

            <p className="mt-1 text-xs text-gray-400">
              Active / paused students
            </p>
          </div>
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          <section className="rounded-2xl border border-gray-200 bg-white p-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-950">
                  Teachers
                </h2>

                <p className="mt-1 text-sm text-gray-500">
                  Primary and assistant teachers.
                </p>
              </div>

              <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-600">
                {assignedTeachers} assigned
              </span>
            </div>

            {teacherAssignments &&
            teacherAssignments.length > 0 ? (
              <div className="mt-5 space-y-3">
                {teacherAssignments.map(
                  (assignment) => {
                    const teacher =
                      teacherMap.get(
                        assignment.teacher_id
                      )

                    return (
                      <div
                        key={assignment.id}
                        className="flex items-center justify-between gap-4 rounded-xl border border-gray-200 p-4"
                      >
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <p className="text-sm font-semibold text-gray-950">
                              {teacher?.full_name ??
                                'Unknown Teacher'}
                            </p>

                            <span
                              className={`rounded-full px-2 py-1 text-[11px] font-semibold ${
                                assignment.teacher_role ===
                                'PRIMARY'
                                  ? 'bg-blue-50 text-blue-700'
                                  : 'bg-gray-100 text-gray-600'
                              }`}
                            >
                              {assignment.teacher_role}
                            </span>
                          </div>

                          <p className="mt-1 text-xs text-gray-500">
                            {teacher?.teacher_code ??
                              '—'}
                          </p>

                          <p className="mt-1 text-xs text-gray-400">
                            Assigned:{' '}
                            {assignment.assigned_at}
                          </p>
                        </div>

                        <form
                          action={removeTeacher}
                        >
                          <input
                            type="hidden"
                            name="assignment_id"
                            value={assignment.id}
                          />

                          <input
                            type="hidden"
                            name="class_id"
                            value={classItem.id}
                          />

                          <button
                            type="submit"
                            className="rounded-lg border border-red-200 px-3 py-2 text-xs font-medium text-red-600 hover:bg-red-50"
                          >
                            Remove
                          </button>
                        </form>
                      </div>
                    )
                  }
                )}
              </div>
            ) : (
              <div className="mt-5 rounded-xl border border-dashed border-gray-300 p-5 text-center">
                <p className="text-sm font-medium text-gray-700">
                  No teachers assigned
                </p>
              </div>
            )}

            <div className="mt-6 border-t border-gray-100 pt-5">
              <h3 className="text-sm font-semibold text-gray-950">
                Assign Teacher
              </h3>

              {availableTeachers.length > 0 ? (
                <form
                  action={assignTeacher}
                  className="mt-4 space-y-3"
                >
                  <input
                    type="hidden"
                    name="class_id"
                    value={classItem.id}
                  />

                  <select
                    name="teacher_id"
                    required
                    defaultValue=""
                    className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm"
                  >
                    <option
                      value=""
                      disabled
                    >
                      Select teacher
                    </option>

                    {availableTeachers.map(
                      (teacher) => (
                        <option
                          key={teacher.id}
                          value={teacher.id}
                        >
                          {teacher.full_name ??
                            teacher.teacher_code}{' '}
                          ({teacher.teacher_code})
                        </option>
                      )
                    )}
                  </select>

                  <select
                    name="teacher_role"
                    required
                    defaultValue={
                      primaryTeacher
                        ? 'ASSISTANT'
                        : 'PRIMARY'
                    }
                    className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm"
                  >
                    {!primaryTeacher && (
                      <option value="PRIMARY">
                        Primary Teacher
                      </option>
                    )}

                    <option value="ASSISTANT">
                      Assistant Teacher
                    </option>

                    {primaryTeacher && (
                      <option value="PRIMARY">
                        Replace Primary Teacher
                      </option>
                    )}
                  </select>

                  <button
                    type="submit"
                    className="w-full rounded-lg bg-gray-950 px-4 py-2.5 text-sm font-semibold text-white hover:bg-gray-800"
                  >
                    Assign Teacher
                  </button>
                </form>
              ) : (
                <p className="mt-3 text-sm text-gray-400">
                  No additional active teachers are
                  available.
                </p>
              )}
            </div>
          </section>

        <section className="mt-6 rounded-2xl border border-gray-200 bg-white p-6">
          <h2 className="text-lg font-semibold text-gray-950">PHẠM VI TRÌNH ĐỘ</h2>
          <p className="mt-1 text-sm text-gray-500">
            Lớp có thể tiếp nhận học viên ở các cấp độ trong phạm vi này. Trình độ hiện tại vẫn được quản lý riêng trên từng học viên.
          </p>
          <form action={setClassLevelScope} className="mt-4 flex flex-wrap gap-3">
            <input type="hidden" name="class_id" value={classItem.id} />
            <label className="text-sm">Từ
              <select name="accepted_from_level_id" className="ml-2 rounded border px-2 py-1" defaultValue={classItem.accepted_from_level_id ?? ''}>
                <option value="">—</option>
                {(levels ?? []).map(level => <option key={level.id} value={level.id}>{level.name}</option>)}
              </select>
            </label>
            <label className="text-sm">Đến
              <select name="accepted_to_level_id" className="ml-2 rounded border px-2 py-1" defaultValue={classItem.accepted_to_level_id ?? ''}>
                <option value="">—</option>
                {(levels ?? []).map(level => <option key={level.id} value={level.id}>{level.name}</option>)}
              </select>
            </label>
            <button className="rounded bg-gray-950 px-3 py-1 text-sm text-white">Lưu phạm vi</button>
          </form>
          <p className="mt-2 text-sm font-medium">{scopeLabel}</p>
        </section>

        <section className="mt-6 rounded-2xl border border-gray-200 bg-white p-6">
          <h2 className="text-lg font-semibold text-gray-950">Buổi học sắp tới</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {(upcomingSessions ?? []).map(session => (
              <li key={session.id}>
                <Link href={`/admin/attendance/${session.id}`} className="font-medium text-gray-950">
                  {session.occurrence_date} · {new Date(session.starts_at).toLocaleTimeString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh', hour: '2-digit', minute: '2-digit' })}
                </Link>
                <span className="ml-2 text-gray-500">{session.occurrence_type === 'MAKEUP' ? 'Học bù' : 'Buổi thường'} · {session.status}</span>
              </li>
            ))}
            {!(upcomingSessions ?? []).length && <li className="text-gray-500">Chưa có ca học được tạo từ lịch.</li>}
          </ul>
        </section>

          <StudentEnrollmentSection
            classId={classItem.id}
            capacity={classItem.capacity}
          />
        </div>

        <section className="mt-6 rounded-2xl border border-gray-200 bg-white p-6">
          <h2 className="text-lg font-semibold text-gray-950">
            Class Information
          </h2>

          <div className="mt-5 grid gap-5 sm:grid-cols-2">
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
                Start Date
              </p>

              <p className="mt-1 text-sm font-medium text-gray-900">
                {classItem.start_date ?? 'Not set'}
              </p>
            </div>

            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
                End Date
              </p>

              <p className="mt-1 text-sm font-medium text-gray-900">
                {classItem.end_date ?? 'Not set'}
              </p>
            </div>
          </div>

          {classItem.notes && (
            <div className="mt-5 border-t border-gray-100 pt-5">
              <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
                Notes
              </p>

              <p className="mt-2 text-sm text-gray-600">
                {classItem.notes}
              </p>
            </div>
          )}
        </section>
      </div>
    </div>
  )
}