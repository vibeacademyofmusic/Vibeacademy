'use server'

import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

import { createClient } from '@/lib/supabase/server'
import { businessDate } from '../../_lib/business-date'
import { planClassTeacherAssignment, type StoredClassTeacher } from '../teacher-assignment'

async function requireSuperAdmin() {
  const supabase = await createClient()

  const { data: claimsData, error: claimsError } =
    await supabase.auth.getClaims()

  if (claimsError || !claimsData?.claims) {
    redirect('/login')
  }

  const { data: isSuperAdmin, error: roleError } =
    await supabase.rpc('has_role', {
      role_code: 'SUPER_ADMIN',
    })

  if (roleError || !isSuperAdmin) {
    redirect('/login?error=Unauthorized')
  }

  return supabase
}

export async function assignTeacher(
  formData: FormData
) {
  const supabase = await requireSuperAdmin()

  const classId = String(
    formData.get('class_id') ?? ''
  ).trim()

  const teacherId = String(
    formData.get('teacher_id') ?? ''
  ).trim()

  const teacherRole = String(
    formData.get('teacher_role') ?? ''
  ).trim()

  if (
    !classId ||
    !teacherId ||
    !['PRIMARY', 'ASSISTANT'].includes(teacherRole)
  ) {
    redirect(
      `/admin/classes/${classId}?error=Invalid%20teacher%20assignment`
    )
  }

  const { data: classItem } = await supabase
    .from('classes')
    .select('id')
    .eq('id', classId)
    .maybeSingle()

  if (!classItem) {
    redirect('/admin/classes?error=Class%20not%20found')
  }

  const { data: teacher } = await supabase
    .from('teachers')
    .select('id, status')
    .eq('id', teacherId)
    .maybeSingle()

  if (!teacher || teacher.status !== 'ACTIVE') {
    redirect(
      `/admin/classes/${classId}?error=Teacher%20is%20not%20active`
    )
  }

  const { data: existing, error: existingError } = await supabase
    .from('class_teachers')
    .select('id, teacher_id, teacher_role, is_active, assigned_at, ended_at')
    .eq('class_id', classId)
    .returns<StoredClassTeacher[]>()

  if (existingError || !existing) {
    redirect(
      `/admin/classes/${classId}?error=Could%20not%20assign%20teacher`
    )
  }

  const plan = planClassTeacherAssignment(existing, {
    teacherId,
    role: teacherRole as 'PRIMARY' | 'ASSISTANT',
    assignedAt: businessDate(),
  })

  if (plan.kind === 'refused') {
    redirect(
      `/admin/classes/${classId}?error=${encodeURIComponent(
        plan.reason === 'history_gap'
          ? 'This teacher already has an assignment history on the class. A second period cannot be stored yet.'
          : 'The current primary teacher started today, so yesterday cannot be used as the handoff date.'
      )}`
    )
  }

  if (plan.kind === 'assign') {
    const closing = plan.closeId
      ? existing.find((row) => row.id === plan.closeId)
      : undefined

    if (plan.closeId && plan.closeOn && closing) {
      const { error: closeError } = await supabase
        .from('class_teachers')
        .update({
          is_active: false,
          ended_at: plan.closeOn,
        })
        .eq('id', plan.closeId)
        .eq('class_id', classId)

      if (closeError) {
        redirect(
          `/admin/classes/${classId}?error=Could%20not%20assign%20teacher`
        )
      }
    }

    const { error } = await supabase
      .from('class_teachers')
      .insert({
        class_id: classId,
        teacher_id: teacherId,
        teacher_role: teacherRole,
        is_active: true,
        assigned_at: plan.assignedAt,
        ended_at: null,
      })

    if (error) {
      if (closing && plan.closeId) {
        await supabase
          .from('class_teachers')
          .update({
            is_active: closing.is_active,
            ended_at: closing.ended_at,
          })
          .eq('id', plan.closeId)
          .eq('class_id', classId)
      }

      console.error(
        'Assign teacher error:',
        error
      )

      if (error.code === '23505') {
        redirect(
          `/admin/classes/${classId}?error=This%20class%20already%20has%20an%20active%20primary%20teacher`
        )
      }

      if (error.message.includes('two overlapping')) {
        redirect(
          `/admin/classes/${classId}?error=` + encodeURIComponent('Giáo viên chính đã có hai ca dạy trùng thời gian. Hãy chọn giáo viên khác hoặc đổi lịch.')
        )
      }

      redirect(
        `/admin/classes/${classId}?error=Could%20not%20assign%20teacher`
      )
    }
  }

  revalidatePath('/admin/classes')
  revalidatePath(`/admin/classes/${classId}`)
  revalidatePath('/admin/session-teachers')

  redirect(
    `/admin/classes/${classId}?success=Teacher%20assigned%20successfully`
  )
}

export async function removeTeacher(
  formData: FormData
) {
  const supabase = await requireSuperAdmin()

  const assignmentId = String(
    formData.get('assignment_id') ?? ''
  ).trim()

  const classId = String(
    formData.get('class_id') ?? ''
  ).trim()

  if (!assignmentId || !classId) {
    redirect(
      `/admin/classes/${classId}?error=Invalid%20teacher%20assignment`
    )
  }

  const { error } = await supabase
    .from('class_teachers')
    .update({
      is_active: false,
      ended_at: businessDate(),
    })
    .eq('id', assignmentId)
    .eq('class_id', classId)

  if (error) {
    console.error(
      'Remove teacher error:',
      error
    )

    redirect(
      `/admin/classes/${classId}?error=Could%20not%20remove%20teacher`
    )
  }

  revalidatePath('/admin/classes')
  revalidatePath(`/admin/classes/${classId}`)
  revalidatePath('/admin/session-teachers')

  redirect(
    `/admin/classes/${classId}?success=Teacher%20removed%20successfully`
  )
}
export async function enrollStudent(
    formData: FormData
  ) {
    const supabase = await requireSuperAdmin()

    const classId = String(
      formData.get('class_id') ?? ''
    ).trim()

    const studentId = String(
      formData.get('student_id') ?? ''
    ).trim()
    const enrolledAt = String(
      formData.get('enrolled_at') ?? ''
    ).trim()

    const startedAt = String(
      formData.get('started_at') ?? ''
    ).trim()
    if (
      !classId ||
      !studentId ||
      !enrolledAt ||
      !startedAt
    ) {
      redirect(
        `/admin/classes/${classId}?error=${encodeURIComponent(
          'Học sinh, ngày ghi danh và ngày bắt đầu học là bắt buộc'
        )}`
      )
    }

    const datePattern = /^\d{4}-\d{2}-\d{2}$/

    if (
      !datePattern.test(enrolledAt) ||
      !datePattern.test(startedAt)
    ) {
      redirect(
        `/admin/classes/${classId}?error=${encodeURIComponent(
          'Ngày ghi danh hoặc ngày bắt đầu học không hợp lệ'
        )}`
      )
    }

    if (startedAt < enrolledAt) {
      redirect(
        `/admin/classes/${classId}?error=${encodeURIComponent(
          'Ngày bắt đầu học không được trước ngày ghi danh'
        )}`
      )
    }


    const { data: classItem } = await supabase
      .from('classes')
      .select(`
        id,
        course_id,
        curriculum_id,
        capacity,
        status
      `)
      .eq('id', classId)
      .maybeSingle()

    if (!classItem) {
      redirect(
        '/admin/classes?error=Class%20not%20found'
      )
    }

    if (
      ['COMPLETED', 'CANCELLED'].includes(
        classItem.status
      )
    ) {
      redirect(
        `/admin/classes/${classId}?error=Students%20cannot%20be%20enrolled%20in%20a%20completed%20or%20cancelled%20class`
      )
    }

    const { data: compatibility } = await supabase.rpc('class_enrollment_compatibility', {
      p_class: classId,
      p_student: studentId,
    })
    if (compatibility && compatibility !== 'IN_SCOPE') {
      const messages: Record<string, string> = {
        OUTSIDE_SCOPE: 'Học viên ngoài phạm vi trình độ của lớp',
        WRONG_PROGRAM: 'Học viên không có chương trình Academic đúng curriculum của lớp',
        ACADEMIC_PROGRAM_MISSING: 'Học viên chưa có chương trình Academic đang hoạt động',
        CURRENT_LEVEL_MISSING: 'Học viên chưa có trình độ hiện tại trên chương trình Academic',
        CLASS_SCOPE_UNCONFIGURED: 'Lớp chưa cấu hình phạm vi trình độ; không thể ghi danh mới',
      }
      redirect(`/admin/classes/${classId}?error=` + encodeURIComponent(messages[String(compatibility)] || String(compatibility)))
    }

    const { data: student } = await supabase
      .from('students')
      .select('id, status')
      .eq('id', studentId)
      .maybeSingle()

    if (!student || student.status !== 'ACTIVE') {
      redirect(
        `/admin/classes/${classId}?error=Student%20is%20not%20active`
      )
    }

    const { data: existingEnrollment } =
      await supabase
        .from('enrollments')
        .select(`
          id,
          status,
          student_curriculum_enrollment_id
        `)
        .eq('student_id', studentId)
        .eq('class_id', classId)
        .maybeSingle()

    if (
      existingEnrollment &&
      ['ACTIVE', 'PAUSED'].includes(
        existingEnrollment.status
      )
    ) {
      redirect(
        `/admin/classes/${classId}?error=Student%20is%20already%20enrolled%20in%20this%20class`
      )
    }

    const {
      count: occupiedSeats,
      error: capacityError,
    } = await supabase
      .from('enrollments')
      .select('id', {
        count: 'exact',
        head: true,
      })
      .eq('class_id', classId)
      .in('status', ['ACTIVE', 'PAUSED'])

    if (capacityError) {
      console.error(
        'Capacity check error:',
        capacityError
      )

      redirect(
        `/admin/classes/${classId}?error=Could%20not%20check%20class%20capacity`
      )
    }

    if (
      (occupiedSeats ?? 0) >= classItem.capacity
    ) {
      redirect(
        `/admin/classes/${classId}?error=Class%20is%20already%20full`
      )
    }

    const { data: course } = classItem.course_id
      ? await supabase
        .from('courses')
        .select('id, curriculum_id')
        .eq('id', classItem.course_id)
        .maybeSingle()
      : { data: null }
    const programId = classItem.curriculum_id || course?.curriculum_id || null

    let academicEnrollmentId: string | null =
      existingEnrollment
        ?.student_curriculum_enrollment_id ?? null

    if (programId) {
      const {
        data: academicEnrollments,
      } = await supabase
        .from('student_curriculum_enrollments')
        .select('id, is_primary')
        .eq('student_id', studentId)
        .eq(
          'curriculum_id',
          programId
        )
        .eq('status', 'ACTIVE')
        .order('is_primary', {
          ascending: false,
        })
        .limit(1)

      academicEnrollmentId =
        academicEnrollments?.[0]?.id ?? null
    }



    if (existingEnrollment) {
      const { error } = await supabase
        .from('enrollments')
        .update({
          student_curriculum_enrollment_id:
            academicEnrollmentId,
          status: 'ACTIVE',
          enrolled_at: enrolledAt,
        started_at: startedAt,
          ended_at: null,
        })
        .eq('id', existingEnrollment.id)

      if (error) {
        console.error(
          'Reactivate enrollment error:',
          error
        )

        redirect(
          `/admin/classes/${classId}?error=Could%20not%20enroll%20student`
        )
      }
    } else {
      const { error } = await supabase
        .from('enrollments')
        .insert({
          student_id: studentId,
          class_id: classId,
          student_curriculum_enrollment_id:
            academicEnrollmentId,
            enrolled_at: enrolledAt,
            started_at: startedAt,
          status: 'ACTIVE',
        })

      if (error) {
        console.error(
          'Enroll student error:',
          error
        )

        if (error.code === '23505') {
          redirect(
            `/admin/classes/${classId}?error=Student%20is%20already%20enrolled`
          )
        }

        redirect(
          `/admin/classes/${classId}?error=Could%20not%20enroll%20student`
        )
      }
    }

    revalidatePath('/admin/classes')
    revalidatePath(`/admin/classes/${classId}`)
    revalidatePath(`/admin/students/${studentId}`)

    redirect(
      `/admin/classes/${classId}?success=Student%20enrolled%20successfully`
    )
  }

  export async function withdrawStudent(
    formData: FormData
  ) {
    const supabase = await requireSuperAdmin()

    const enrollmentId = String(
      formData.get('enrollment_id') ?? ''
    ).trim()

    const classId = String(
      formData.get('class_id') ?? ''
    ).trim()

    const studentId = String(
      formData.get('student_id') ?? ''
    ).trim()

    if (
      !enrollmentId ||
      !classId ||
      !studentId
    ) {
      redirect(
        `/admin/classes/${classId}?error=Invalid%20student%20enrollment`
      )
    }

    const today = new Date()
      .toISOString()
      .slice(0, 10)

    const { error } = await supabase
      .from('enrollments')
      .update({
        status: 'WITHDRAWN',
        ended_at: today,
      })
      .eq('id', enrollmentId)
      .eq('class_id', classId)
      .eq('student_id', studentId)
      .in('status', ['ACTIVE', 'PAUSED'])

    if (error) {
      console.error(
        'Withdraw student error:',
        error
      )

      redirect(
        `/admin/classes/${classId}?error=Could%20not%20withdraw%20student`
      )
    }

    revalidatePath('/admin/classes')
    revalidatePath(`/admin/classes/${classId}`)
    revalidatePath(`/admin/students/${studentId}`)

    redirect(
      `/admin/classes/${classId}?success=Student%20withdrawn%20successfully`
    )
  }